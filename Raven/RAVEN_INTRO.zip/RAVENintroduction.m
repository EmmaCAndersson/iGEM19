%% RAVEN installation
% As detailed in the PDF on RAVEN installation, make sure that the
% folder (incl. subfolders) where RAVEN is installed are added in MATLAB.
% If not added, run pathtool (see installation PDF).

% It doesn't hurt to run the following two lines to ensure that the
% installation was succesful:

global CBT_LP_SOLVER
CBT_LP_SOLVER = 'glpk';
checkInstallation;

%% RAVEN exercise
% 1. I/O of Models
% 1.1.
% Make sure you go to the location where the KKR063 MATLAB files were
% stored. In my case, I unzipped it all here:
cd('C:\KKR063');

model = importModel('yeastGEM.xml');
% parameter 1: Import SBML model, named yeastGEM.xml;
% parameter 2: remove exchange metabolites ('true'), these are not mass
% balanced and should therefore not be included in FBA
% parameter 3: and it is not an SBML Level 2-style model ('false').
 
% It will likely report that errors are encountered, but as long as there
% is no text in red, you can assume that the function has succeeded. The
% model is loaded.
 
% If you didn't manage to import the file (libSBML is not working), you can
% also open yeastGEM.mat, which is the same model but then already
% in MATLAB format.
 
% It can be good to keep a copy of the model before you make any changes.
% You can then always copy it back, which is faster than importing again.
modelCOPY = model; % Makes a copy
model = modelCOPY; % Sets back the copy
 
% 1.2.
% Export the model in Excel format:
exportToExcelFormat(model, 'yeastGEM.xlsx');
 
% If you want more information on the parameters that are used in a
% particular function, this is normally displayed if you use 'help':
help exportToExcelFormat;
 
%% 2. Model Structure
% You should know your model structure in Matlab well! This helps to save
% time, which you may spend when importing SBML/Excel models every time.
% Use 'help' function to see the list of model fields.
help importModel;
 
%% 3. Flux Balance Analysis
% 3.1.
% Set parameter value
model = setParam(model, 'obj', 'r_4041', 1); % Set growth as obj function.
 
% If you run constructEquations with its default settings
% (constructEquations(model)), all the reactions will be printed. Try to
% print only reaction 'r_4041'. Hint: have 'model.rxns' as parameter 2
 
% 3.2.
% Set glucose uptake to 0.5 mmol/gDCW/h
model = setParam(model, 'lb', 'r_1714', -0.5);
 
% 3.3.
% Let's do FBA and print the values for exchange fluxes
sol = solveLP(model, 1)
printFluxes(model, sol.x);
 
% 3.4.
% To make things simplier, save each FBA solution in different variables,
% e.g. sol05, sol075, sol1, sol125, etc.
 
% 3.5.
% We can use the results from the very first FBA
 
% 3.5.a.
model=importModel('yeastGEM.xml',false)
[exchangeRxns, exchangeRxnsIndexes] = getExchangeRxns(modelCOPY);
 
% 3.5.b.
balanceStructure = getElementalBalance(model, exchangeRxns);
% balanceStructure contains several fields, showing the number of total
% composition for all reactants and all products respectively (leftComp,
% rightComp). It doesn't matter which one we will use to calculate biomass
% composition, so we use leftComp for further calculations
 
% 3.5.d.
 
% Useful commands:
 
% arrayB = transpose(arrayA); array transposition
% matrixC = matrixA * matrixB; matrix multiplication
 
%% 4. Random sampling
% 4.1
solutions = randomSampling(model, 1000);
% 4.2
solution(abs(solution) < 1e-10) = 0; % Set the very low fluxes equal to zero
solution = transpose(solution); % Transpose the matrix (swap columns and rows) for easier handling.
 
% Make a structure that we can export to Excel for easier evaluation
rsOut(1, :) = model.rxns; % The first column we want reaction IDs
rsOut(2, :) = num2cell(mean(solution)); % Second column we want the means of the fluxes. As this structure is no longer an all-numerical matrix, we need to convert from numbers to cells (num2cell).
rsOut(3, :) = num2cell(std(solution)); % Standard deviation
rsOut(4, :) = num2cell(min(solution)); % Minimum flux
rsOut(5, :) = num2cell(max(solution)); % Maximum flux
rsOut(6, :) = model.rxnNames; % Reaction names
rsOut(7, :) = constructEquations(model); % Reaction equations
rsOut = cat(1, {'rxnID', 'mean', 'sd', 'max', 'min', 'rxnName', 'rxnEq'}, transpose(rsOut));
xlswrite('randomSampling.xlsx',rsOut);
 

%% 5. KO Evaluation
 
% 5.1.
% Block uptake for all exchange metabolites and allow excretion
exchangeRxns = getExchangeRxns(model);
model=setParam(model,'lb',exchangeRxns,0);
model=setParam(model,'ub',exchangeRxns,1000);
model=setParam(model,'lb','r_1654',-1000); % 'ammonium exchange';
model=setParam(model,'lb','r_1714',-1000); % 'water exchange' ;
model=setParam(model,'lb','r_1861',-1000); % 'iron(2+) exchange';
model=setParam(model,'lb','r_1992',-1000); % 'oxygen exchange';
model=setParam(model,'lb','r_2005',-1000); % 'phosphate exchange';
model=setParam(model,'lb','r_2060',-1000); % 'sulphate exchange';
model=setParam(model,'lb','r_2100',-1000); % 'H+ exchange' ;
model=setParam(model,'lb','r_1714',-10); % 'D-glucose exchange' ;
 
% Run single gene deletion and obtain the list of essential genes
[~, ~, ~, details] = findGeneDeletions(model,'sgd','fba');
essentialGenes = model.genes(details==3);
 
%% 6. FSEOF
% Add reactions for PHB production:
rxnToAdd.rxns = {'AACR', 'P3HBP', 'PHBtr', 'PHBex'};
rxnToAdd.equations = {'acetoacetyl-CoA[c] + NADPH[c] + H+[c] <=> 3-hydroxybutyryl-CoA[c] + NADP(+)[c]',...
	'3-hydroxybutyryl-CoA[c] <=> coenzyme A[c] + PHB[c]','PHB[c] <=> PHB[e]',...
	'PHB[e] =>'};
rxnToAdd.rxnNames = {'acetoacetyl-CoA reductase',...
	'poly(3-hydroxybutyrate) polymerase','PHB transport','PHB exchange'};
rxnToAdd.subSystems = {'','','',''};
rxnToAdd.lb = [0 0 0 0];
rxnToAdd.ub = [1000 1000 1000 1000];
model = addRxns(model, rxnToAdd, 3, '', true);
 
% 6.1 Calculate maximum theoretical PHB yield
model = setParam(model, 'obj', 'r_4041', 1); % Set PHB production as obj function.
sol = solveLP(model, 1)
printFluxes(model, sol.x)
 
% 6.2 Perform FSEOF to find possible targets for overexpression/downregulation.

FSEOF(model,'r_4041','PHBex',10,0.9,'PHB_FSEOF.out')
 
% 6.3 Add exchange reactions for TAG production. Adjust to match your own metabolite of interest.
rxnToAdd.rxns = {'TAGex'};
rxnToAdd.equations = {'triglyceride[c] =>'};
rxnToAdd.rxnNames = {'TAG exchange'};
rxnToAdd.subSystems = {''};
rxnToAdd.lb = [0];
rxnToAdd.ub = [1000];
model = addRxns(model, rxnToAdd, 3, '', true);
 
model = setParam(model, 'obj', 'TAGex', 1); % Set TAG excretion as obj function.
sol = solveLP(model, 1)
printFluxes(model, sol.x)
FSEOF(model,'r_4041','TAGex',10,0.9,'TAG_FSEOF.out')